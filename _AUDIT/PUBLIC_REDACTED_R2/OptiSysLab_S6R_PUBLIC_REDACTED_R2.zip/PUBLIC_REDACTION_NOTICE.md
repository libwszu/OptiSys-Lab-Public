# PUBLIC_REDACTED audit edition

Package ID: OptiSysLab_S6R_PUBLIC_REDACTED_R2. Schema: optisys.public_redacted_audit/2.

This is a newly built public redacted copy, not the unchanged historical audit ZIP. Personal/local provenance and legacy private revision identifiers were replaced with explicit placeholders. Scientific arrays, CSV samples, configurations, seeds, thresholds and judgments are retained. Editable-install egg-info metadata is omitted because it is regenerated on installation.

The private original is retained separately. Its SHA-256 is 2fe48fa07fa6001bc056309e4787765d1a576af0c9b99a9dedd15cf3c5abae39; this hash identifies the private source and is not the checksum of this package. Private member/commit mappings are not distributed. The new manifest and SHA256SUMS describe this edition only. Historical PASS/FAIL/PARTIAL and media-delivery records retain their original scope. No measurements or external adoption are claimed.

Verify this edition using `python scripts/verify_public_audit.py ARCHIVE.zip --expected-sha256 TRUSTED_NEW_SHA256`. Then run `python repro/verify_s6r.py --root . --output artifacts/public-s6.json` in the extracted directory. The legacy `s6r_verify_audit.py` checks the legacy format and must not be used to certify this edition.
